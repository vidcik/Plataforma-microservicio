// admin/src/index.js
import express from "express";
import bodyParser from "body-parser";
import Docker from "dockerode";
import { nanoid } from "nanoid";

const app = express();
const docker = new Docker({ socketPath: "/var/run/docker.sock" });

app.set("view engine", "ejs");
app.set("views", "./src/views");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const NETWORK = "ms-net";
const MS_IMAGE = "ms-template:latest";
const PLATFORM_EXTERNAL_URL = process.env.PLATFORM_EXTERNAL_URL || "http://localhost";
const ROBLE_BASE_URL = process.env.ROBLE_BASE_URL || "https://roble-api.openlab.uninorte.edu.co";

function msLabels(id) {
  return {
    "ms.platform": "true",
    "ms.id": id,
    "traefik.enable": "true",
    [`traefik.http.routers.ms_${id}.rule`]: `PathPrefix(\`/ms/${id}\`)`,
    [`traefik.http.routers.ms_${id}.entrypoints`]: "web",
    [`traefik.http.middlewares.ms_${id}_stripprefix.stripprefix.prefixes`]: `/ms/${id}`,
    [`traefik.http.routers.ms_${id}.middlewares`]: `ms_${id}_stripprefix`,
    [`traefik.http.services.ms_${id}.loadbalancer.server.port`]: "3000",
    "traefik.docker.network": NETWORK,
  };
}


async function listMicroservices() {
  const containers = await docker.listContainers({ all: true, filters: { label: ["ms.platform=true"] } });
  return containers.map(c => ({
    id: c.Labels["ms.id"],
    name: c.Names?.[0]?.replace("/",""),
    state: c.State,
    status: c.Status,
    url: `${PLATFORM_EXTERNAL_URL}/ms/${c.Labels["ms.id"]}/health`,
  }));
}

app.get("/", async (req, res) => {
  const services = await listMicroservices().catch(() => []);
  res.render("index", { services, ROBLE_BASE_URL, PLATFORM_EXTERNAL_URL });
});

app.post("/services", async (req, res) => {
  const { name, route, processingType } = req.body;
  const id = route?.trim() || nanoid(8);

  try {
    // pull image if missing (optional)
    // await docker.pull(MS_IMAGE);

    const labels = msLabels(id);
    const container = await docker.createContainer({
      Image: MS_IMAGE,
      name: `ms_${id}`,
      Env: [
        `SERVICE_ID=${id}`,
        `SERVICE_NAME=${name || "microservice"}`,
        `PROCESSING_TYPE=${processingType || "none"}`,
        `ROBLE_BASE_URL=${ROBLE_BASE_URL}`
      ],
      Labels: labels,
      HostConfig: {
        NetworkMode: NETWORK
      },
      NetworkingConfig: {
        EndpointsConfig: { [NETWORK]: {} }
      }
    });
    await container.start();
    res.redirect("/");
  } catch (err) {
    res.status(500).send(`Error creando microservicio: ${err.message}`);
  }
});

app.post("/services/:id/delete", async (req, res) => {
  const { id } = req.params;
  try {
    const containers = await docker.listContainers({ all: true, filters: { label: [`ms.id=${id}`] } });
    if (containers.length === 0) return res.status(404).send("No existe");
    const container = docker.getContainer(containers[0].Id);
    try { await container.stop(); } catch {}
    await container.remove();
    res.redirect("/");
  } catch (err) {
    res.status(500).send(`Error eliminando microservicio: ${err.message}`);
  }
});

app.listen(3001, () => {
  console.log("Admin UI en http://localhost:3001");
});
