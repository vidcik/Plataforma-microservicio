// microservice/src/index.js
import express from "express";
import fetch from "node-fetch";

const app = express();
app.use(express.json());

const SERVICE_ID = process.env.SERVICE_ID || "ms";
const SERVICE_NAME = process.env.SERVICE_NAME || "microservice";
const PROCESSING_TYPE = process.env.PROCESSING_TYPE || "none";
const ROBLE_BASE_URL = (process.env.ROBLE_BASE_URL || "https://roble-api.openlab.uninorte.edu.co").replace(/\/+$/,"");

app.get("/health", (req, res) => {
  res.json({ ok: true, serviceId: SERVICE_ID, name: SERVICE_NAME, processing: PROCESSING_TYPE });
});

// Ejemplo de endpoint principal
app.all("/api", async (req, res) => {
  try {
    const auth = req.headers["authorization"];
    if (!auth) {
      return res.status(401).json({ error: "Falta Authorization: Bearer <token>" });
    }

    // Ejemplo de lectura de parámetros (query o body)
    const params = { ...req.query, ...(req.body || {}) };

    // Demostración: reenvío del token a Roble (ajusta la ruta final a la API de Roble)
    // Aquí suponemos un recurso "records" con una tabla indicada por ?table=
    // Consulta la doc para las rutas exactas.
    const table = params.table || "demo_table";
    const url = `${ROBLE_BASE_URL}/database/records?table=${encodeURIComponent(table)}`;

    // Llamado a Roble
    const r = await fetch(url, {
      method: "GET",
      headers: { "Authorization": auth, "Accept": "application/json" }
    });

    if (r.status === 401) return res.status(401).json({ error: "Token inválido o expirado" });
    if (r.status === 403) return res.status(403).json({ error: "Acceso denegado" });

    const data = await r.json().catch(() => ({}));

    // Procesamiento muy simple según PROCESSING_TYPE
    let result = data;
    if (PROCESSING_TYPE === "filter" && Array.isArray(data?.records)) {
      result = data.records.filter(x => x && typeof x === "object");
    } else if (PROCESSING_TYPE === "aggregate" && Array.isArray(data?.records)) {
      result = { count: data.records.length };
    } else if (PROCESSING_TYPE === "analyze") {
      result = { fields: Object.keys(data || {}) };
    }

    res.json({ serviceId: SERVICE_ID, processing: PROCESSING_TYPE, params, result });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal Server Error", detail: e.message });
  }
});

const port = 3000;
app.listen(port, () => {
  console.log(`[${SERVICE_ID}] listening on ${port}`);
});
