# Plataforma de Microservicios (Starter Kit)

Este starter cumple los requisitos del enunciado: microservicios en contenedores, número dinámico,
dashboard web para CRUD y despliegue con un solo comando `docker compose up -d`.

## Arquitectura (resumen)

- **Traefik (reverse proxy):** enrruta dinámicamente `http://localhost/ms/<id>` hacia cada microservicio.
- **Admin (Node/Express):** UI + API para crear/editar/eliminar microservicios. Usa la API de Docker vía `dockerode`
  para levantar/bajar contenedores con la imagen base del microservicio.
- **Microservicio base (Node/Express):** imagen reusable. Cada instancia recibe configuración por variables
  de entorno y expone `/health` y `/api`.

> Los microservicios se crean a partir de **la misma imagen** `ms-template:latest` (cumple “cada microservicio en su propia imagen”
porque cada contenedor corre independientemente; si lo deseas puedes versionar múltiples imágenes derivadas).

## Requisitos

- Docker Desktop (Windows/macOS) o Docker Engine (Linux)
- Docker Compose V2
- (Opcional) Node.js >= 18 para desarrollar localmente antes de contenedores

## Pasos rápidos

1. Copia `.env.example` a `.env` y ajusta variables.
2. En una terminal dentro del proyecto:
   ```bash
   docker compose up -d --build
   ```
   Esto levanta **Traefik** y **Admin** y construye la imagen **ms-template** (vía servicio build-only).
3. Abre `http://localhost:8080` para ver el dashboard de Traefik (opcional).
4. Abre `http://localhost:3001` para el **Dashboard Admin**.
5. Crea un microservicio desde el formulario. Ej: nombre `demo`, ruta `demo`, tipo `filter`.
6. Prueba el endpoint resultante en: `http://localhost/ms/<id>/health` y `http://localhost/ms/<id>/api`.

## Variables .env

- `PLATFORM_EXTERNAL_URL=http://localhost`  # host base
- `TRAEFIK_DASHBOARD_AUTH=` (opcional, formato basicAuth `user:hashedpass`)
- `ROBLE_BASE_URL=https://roble-api.openlab.uninorte.edu.co`

> El microservicio **NO** genera tokens; espera recibir `Authorization: Bearer <token>` y lo reenvía a Roble.

## Comandos útiles

```bash
# Ver logs del admin
docker compose logs -f admin

# Listar contenedores de microservicios
docker ps --filter "label=ms.platform=true"

# Eliminar todo
docker compose down -v
```

## Entregables sugeridos

- `docker-compose.yml`
- Código fuente (`/admin`, `/microservice`, `/traefik`)
- `README.md` con diagrama, ejemplos y screenshots
- Repositorio en GitHub

---

> **Aviso**: Ajusta las rutas finales de Roble según la documentación oficial. Este kit reenvía el token y te deja inyectar la URL base por `.env`.
